package com.sbi;

public interface Vehicle {
	public void drive();
}
