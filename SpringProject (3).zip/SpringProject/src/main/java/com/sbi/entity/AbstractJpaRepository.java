package com.sbi.entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

@Repository
public abstract class AbstractJpaRepository {
	@PersistenceContext(unitName="SpringJPA")
	private EntityManager entityManager;
	public EntityManager getEntityManager() { return entityManager; }
}
