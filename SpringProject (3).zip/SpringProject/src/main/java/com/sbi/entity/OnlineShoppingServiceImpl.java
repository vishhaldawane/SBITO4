package com.sbi.entity;

import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class OnlineShoppingServiceImpl implements OnlineShoppingService {
	private OrderRepository orderRepository;
	private PaymentRepository paymentRepository;
	private ProductRepository productRepository;
	
	@Autowired
	public void init(OrderRepository orderRepository, 
			PaymentRepository paymentRepository,
			ProductRepository productRepository)
	{
		this.orderRepository=orderRepository;
		this.paymentRepository=paymentRepository;
		this.productRepository=productRepository;
	}
	
	@Transactional(propagation = Propagation.REQUIRED, timeout = 30)
	public void placeOrder(Order order) {
			
			
			order.setQuantity(5);
			
			System.out.println("Generating order....");
			orderRepository.processOrder(order);
			System.out.println("Order generated....");
			
			System.out.println("Generating payment details....");
			Payment payment = new Payment();
			
			Scanner scan1 = new Scanner(System.in);
			Scanner scan2 = new Scanner(System.in);
			payment.setOrderId(order.getOrderId());
			System.out.println("Enter the quantity : ");
			int quantity = scan1.nextInt();
			System.out.println("Enter the price    : ");
			double price = scan2.nextDouble();
			order.setPrice(price);
			order.setQuantity(quantity);
			payment.setAmount(quantity* price);
			//payment.setAmount(order.getQuantity() * order.getPrice());
			paymentRepository.processPayment(payment);
			System.out.println("Payment details....generated....");
			
			System.out.println("Reducing the STOCK details....");
			productRepository.reduceStock(order.getProductId(), 
					quantity);
			System.out.println("Stock reduced....");
	}

}
