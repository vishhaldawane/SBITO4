package com.sbi.orm;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sbi.orm.exceptions.CarAlreadyExistsException;
import com.sbi.orm.exceptions.CarNotFoundException;

@Service //4
public class CarServiceImpl implements CarService {
	
	@Autowired CarRepository carRepo;
	
	public void saveCarService(Car carObj) {
		Car theCar = carRepo.selectCar(carObj.getCarId());
		if(theCar != null) {
			CarAlreadyExistsException e = new CarAlreadyExistsException("This car already exists!!!");
			throw e;
		} else {
			carRepo.insertCar(carObj);
		}
	}

	@Override
	public void modifyCarService(Car carObj) {
		Car theCar = carRepo.selectCar(carObj.getCarId());
		if(theCar==null) {
			throw new CarNotFoundException("This car does not exists : "+carObj.getCarId());
		}
		else {		carRepo.updateCar(carObj);		}
	}

	@Override
	public void removeCarService(int carId) {
		Car theCar = carRepo.selectCar(carId);
		if(theCar == null) {
			throw new CarNotFoundException("This car does not exists : "+carId);
		} 
		else {
			carRepo.deleteCar(carId);
		}
	}

	@Override
	public Car findCarService(int carId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Car> findAllCarsService() {
		// TODO Auto-generated method stub
		return null;
	}

}
