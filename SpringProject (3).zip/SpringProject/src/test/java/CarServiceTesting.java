import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.orm.Car;
import com.sbi.orm.CarService;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:spring_orm.xml"})
public class CarServiceTesting {

	@Autowired
	CarService carService;
	
	@Test public void saveCarTest() {
		Car theCar = new Car();
		theCar.setCarId(10);	
		theCar.setCarName("Toyota Altis");
		carService.saveCarService(theCar);
	}
	
	@Test public void modifyCarTest() {
		Car theCar = new Car();
		theCar.setCarId(18);
		theCar.setCarName("VW POLO");
		carService.modifyCarService(theCar);
	}
}
