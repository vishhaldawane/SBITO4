import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sbi.entity.OnlineShoppingService;
import com.sbi.entity.Order;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(locations = {"classpath:spring_orm.xml"})
public class OrderTest {

	
	@Autowired
	private OnlineShoppingService onlineShopping;
	
	@Test
	public void testTransaction() {
		Order order = new Order();
		order.setProductId(123);
		//order.setPrice(650.00);
		//order.setQuantity(5);
		onlineShopping.placeOrder(order);
	}
	
	
}
