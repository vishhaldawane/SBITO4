package onetomany;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import onetoone.Employee;

@Entity
@Table(name="dept11")
public class Department {
	
	@Id
	@Column(name="dept_no")
	private int departmentNumber;
	
	@Column(name="dept_name",length=20)
	private String departmentName;
	
	@Column(name="dept_loc",length=20)
	private String departmentlocation;
	
	@OneToMany(mappedBy="dept", cascade = CascadeType.ALL, fetch = FetchType.EAGER, orphanRemoval = true)
	List<Employee> employees;

	
	
	public Department() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getDepartmentNumber() {
		return departmentNumber;
	}

	public void setDepartmentNumber(int departmentNumber) {
		this.departmentNumber = departmentNumber;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

	public String getDepartmentlocation() {
		return departmentlocation;
	}

	public void setDepartmentlocation(String departmentlocation) {
		this.departmentlocation = departmentlocation;
	}

	public List<Employee> getEmployees() {
		return employees;
	}

	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}

	public Department(int departmentNumber, String departmentName, String departmentlocation) {
		super();
		this.departmentNumber = departmentNumber;
		this.departmentName = departmentName;
		this.departmentlocation = departmentlocation;
		
	}
	
	

}
