package onetomany;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import bank.dao.BaseDAO;
import bank.dao.BaseDAOImpl;
import onetoone.Employee;

public class OneToManyTesting {
	
	BaseDAO base = new BaseDAOImpl();
	
	@Test
	public void addNewDepartmentWithNewEmployees() {
		
		Department dept = new Department(30, "Sales", "New Delhi");
		
		Employee emp1 = new Employee("Suresh",5000,dept);
		Employee emp2 = new Employee("Naresh",6000,dept);
		Employee emp3 = new Employee("Rajesh",7000,dept);
		
		List<Employee> newEmpList = new ArrayList<Employee>();
		newEmpList.add(emp1);
		newEmpList.add(emp2);
		newEmpList.add(emp3);
		
		dept.setEmployees(newEmpList);
		
		base.persist(dept);
		
	}
	
	@Test
	public void upraiseSalaryBy10PercentOfADeptTest()
	{

		
		
		Department dept = base.find(Department.class, 30);
		
		Assertions.assertTrue(dept!=null);
		
		List<Employee> emps =  dept.getEmployees();
		
		for (Employee employee : emps) {
			double currentSalary = employee.getBasicSalary();
			System.out.println("Current salary of "+employee.getEmployeeNumber()+" is "+currentSalary);
			double newSalary = currentSalary + currentSalary *0.10;
			System.out.println("Revised salary of "+employee.getEmployeeNumber()+" is "+newSalary);
			employee.setBasicSalary(newSalary);
		}
		base.merge(dept);
	}
	
	@Test
	public void deleteEmployeesBelongedToADepartment() {
		
		Department dept = base.find(Department.class, 30);
		
		Assertions.assertTrue(dept!=null);
		
		List<Employee> emps =  dept.getEmployees();
		System.out.println("size of emps : "+emps.size());
		
		for (Employee employee : emps) {
			System.out.println("Employee found : "+employee.getEmployeeNumber());
			if(employee.getEmployeeNumber()==53) {
				System.out.println("Employee removed..."+employee.getEmployeeNumber());
				emps.remove(employee);
				break;
			}
		}
		System.out.println("after delete : size of emps : "+emps.size());
		base.merge(dept);
	}
}



