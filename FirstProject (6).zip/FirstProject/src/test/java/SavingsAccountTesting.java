import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import bank.SavingsAccount;

//TDD - test driven development

public class SavingsAccountTesting {

	EntityManagerFactory entityManagerFactory = 
			Persistence.createEntityManagerFactory("MyJPA");
	//System.out.println("Got the Entity Manager Factory : "+entityManagerFactory);
	
	EntityManager entityManager = 
			entityManagerFactory.createEntityManager();
	//System.out.println("Entity Manager : "+entityManager );
	
	@Test
	public void creationOfSavingsAccountTest()
	{
		System.out.println("Begin testing....");
		
		SavingsAccount savObj1 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj1.setAccno(100);
		savObj1.setAccHolder("Jane");
		savObj1.setBalance(70000);
		
		SavingsAccount savObj2 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj2.setAccno(102);
		savObj2.setAccHolder("Smith");
		savObj2.setBalance(80000);
		
		SavingsAccount savObj3 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj3.setAccno(103);
		savObj3.setAccHolder("Peter");
		savObj3.setBalance(90000);
		
		SavingsAccount savObj4 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj4.setAccno(104);
		savObj4.setAccHolder("Martin");
		savObj4.setBalance(77000);
		
		SavingsAccount savObj5 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj5.setAccno(105);
		savObj5.setAccHolder("Julie");
		savObj5.setBalance(66600);
		
		
		
		System.out.println("Object is filled up....");
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
				entityManager.persist(savObj1); //INSERT QUERY FIRED HERE
				entityManager.persist(savObj2); //INSERT QUERY FIRED HERE
				entityManager.persist(savObj3); //INSERT QUERY FIRED HERE
				entityManager.persist(savObj4); //INSERT QUERY FIRED HERE
				entityManager.persist(savObj5); //INSERT QUERY FIRED HERE
				System.out.println("Savings Account Object persited...");
		trans.commit(); //end the transaction
		
		entityManager.close();
		System.out.println("Entity Manager closed.....");
		
		System.out.println("End testing....");
	}
	
	@Test
	public void creationOfSavingsAccountTest2()
	{
		System.out.println("Begin testing....");
		
		SavingsAccount savObj1 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj1.setAccno(106);
		savObj1.setAccHolder("Jayant");
		savObj1.setBalance(70000);
		
		System.out.println("Object is filled up....");
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
				entityManager.persist(savObj1); //INSERT QUERY FIRED HERE
				
				System.out.println("Savings Account Object persited...");
		trans.commit(); //end the transaction
		
		entityManager.close();
		System.out.println("Entity Manager closed.....");
		
		System.out.println("End testing....");
	}
	
	@Test 
	public void findSavingsAccountTest() {
		Assertions.assertTrue(entityManagerFactory!=null);
		Assertions.assertTrue(entityManager!=null);
		SavingsAccount sa = entityManager.find(SavingsAccount.class, 120);
		Assertions.assertTrue(sa!=null);
		System.out.println("Object found...");
		System.out.println("ACNO   : "+sa.getAccno());
		System.out.println("ACNAME : "+sa.getAccHolder());
		System.out.println("ACBAL  : "+sa.getBalance());
	}
	
	@Test 
	public void findAllSavingsAccountsTest() {
		Assertions.assertTrue(entityManagerFactory!=null);
		Assertions.assertTrue(entityManager!=null);
		
		Query query = entityManager.createQuery("from SavingsAccount");
		
		List<SavingsAccount> savObjList = query.getResultList();
		
		Assertions.assertTrue(savObjList.size()>0);
		for (SavingsAccount sa : savObjList) {
			System.out.println("ACNO   : "+sa.getAccno());
			System.out.println("ACNAME : "+sa.getAccHolder());
			System.out.println("ACBAL  : "+sa.getBalance());
			System.out.println("--------------------");
		}
	}
	
	@Test 
	public void modifySavingsAccountTest() {
		Assertions.assertTrue(entityManagerFactory!=null);
		Assertions.assertTrue(entityManager!=null);
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
		
			SavingsAccount sa = entityManager.find(SavingsAccount.class, 102);
			//	attached with the ORM session
			Assertions.assertTrue(sa!=null);
			System.out.println("Object found...");
			System.out.println("current ACNO   : "+sa.getAccno());
			System.out.println("current ACNAME : "+sa.getAccHolder());
			System.out.println("current ACBAL  : "+sa.getBalance());
		
			System.out.println("Setting new details on the object...");
			
			sa.setAccHolder("Smita");
			sa.setBalance(88800);
		
			entityManager.merge(sa); // update query fired..
			
		trans.commit();
	}
	
	@Test 
	public void deleteSavingsAccountTest() {
		Assertions.assertTrue(entityManagerFactory!=null);
		Assertions.assertTrue(entityManager!=null);
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
		
			SavingsAccount sa = entityManager.find(SavingsAccount.class, 103);
			//	attached with the ORM session
			Assertions.assertTrue(sa!=null);
			System.out.println("Object found...");
			System.out.println("current ACNO   : "+sa.getAccno());
			System.out.println("current ACNAME : "+sa.getAccHolder());
			System.out.println("current ACBAL  : "+sa.getBalance());
		
			System.out.println("Deleting this object");
		
			entityManager.remove(sa); // Delete query fired..
			
		trans.commit();
	}
}
