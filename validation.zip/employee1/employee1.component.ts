import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee1',
  templateUrl: './employee1.component.html',
  styleUrls: ['./employee1.component.css']
})
export class Employee1Component implements OnInit {
  empno:number=0;
  constructor() { }
  ngOnInit(): void {  }
  submitFormDataHere (result:any) {
    console.log('submitFormDataHere() invoked...');
    console.log('Emp Number : '+result.eno);
    console.log('Emp Name   : '+result.ename);
    console.log('Emp Email  : '+result.email);
    console.log('Emp DOB    : '+result.dob);
  }

}
