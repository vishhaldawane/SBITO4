import { Component, OnInit } from '@angular/core';
import { User } from '../User';

@Component({
  selector: 'app-about-company',
  templateUrl: './about-company.component.html',
  styleUrls: ['./about-company.component.css']
})
export class AboutCompanyComponent implements OnInit {

  data:any;
  userObj:User;
  constructor() {

    
    this.data = sessionStorage.getItem('anyKey');
    this.userObj = JSON.parse(this.data);
   }

  ngOnInit(): void {
  }

}
