import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutCompanyComponent } from './about-company/about-company.component';
import { AboutEmployeesComponent } from './about-employees/about-employees.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { TermsComponent } from './terms/terms.component';

const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'about',
    children: [
      {path:'company',component:AboutCompanyComponent},      
      {path:'employees',component:AboutEmployeesComponent},      
      {path:'', component:AboutComponent},
      {path:'**',component:PageNotFoundComponent}
    ]
  },
  {path:'privacy',component:PrivacyComponent},
  {path:'terms',component:TermsComponent},
  {path:'',redirectTo: '/home', pathMatch:'full'},
  {path:'**',component:PageNotFoundComponent},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

