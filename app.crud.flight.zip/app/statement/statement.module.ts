import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MonthlyStatementComponent } from './monthly-statement/monthly-statement.component';
import { YearlyStatementComponent } from './yearly-statement/yearly-statement.component';
import { CustomStatementComponent } from './custom-statement/custom-statement.component';



@NgModule({
  declarations: [
    MonthlyStatementComponent,
    YearlyStatementComponent,
    CustomStatementComponent
  ],
  exports: [
    MonthlyStatementComponent
  ],
  imports: [
    CommonModule
  ]
})
export class StatementModule { }
