import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-employee3',
  templateUrl: './employee3.component.html',
  styleUrls: ['./employee3.component.css']
})
export class Employee3Component implements OnInit {

  requiredForm!:FormGroup;
  constructor(private fb : FormBuilder) { 
    this.myForm();
  }

  onSubmit() {
    console.log('onsubmit invoked...');
  }

  get username() {
    console.log('get username() invoked..');
    return this.requiredForm.get('firstname');
  }
  myForm() {
    this.requiredForm = new FormGroup( {
      username : new FormControl('',[Validators.required,Validators.minLength(10)]),
      password : new FormControl('',Validators.required),
      age : new FormControl('',Validators.required),
      address : new FormControl('',Validators.required),
    })
  }

  ngOnInit(): void {
    
  }

}
