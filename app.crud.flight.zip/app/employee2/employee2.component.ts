import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-employee2',
  templateUrl: './employee2.component.html',
  styleUrls: ['./employee2.component.css']
})
export class Employee2Component implements OnInit {

  constructor() { }

  dataGroup:any;
  username!:string;password!:string;age!:number;address!:string;
  ngOnInit(): void {
    this.dataGroup = new FormGroup({
        a: new FormControl("Hi UserName"),    b: new FormControl("Hi Password"),
        c: new FormControl("Hi Age"),         d: new FormControl("Hi Address")});
    }
  msg!:string;
  onClickSubmit(result:any) {
    console.log('a :'+result.a);    console.log('b :'+result.b);
    console.log('c :'+result.c);    console.log('d :'+result.d);
    this.username=result.a; this.password=result.b; this.age=result.c; this.address=result.d;
    console.log('username :'+this.username);    console.log('password :'+this.password);
    console.log('age      :'+this.age);    console.log('address  :'+this.address);
    
  }

  checkAge() {
    console.log('checking age '+this.age);
    if(this.age < 18 || this.age > 56) {
      this.msg="Invalid employee age";
    }
    else {
      this.msg="Valid employee age";
    }
  }
}
