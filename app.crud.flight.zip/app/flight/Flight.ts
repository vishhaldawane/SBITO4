export class Flight {
	
	flightNumber!:number;
	airline!:string;
	sourceCity!:string;
	targetCity!:string;
	flightDepartureTime!: Date;
	flightArrivalTime!: Date;
}