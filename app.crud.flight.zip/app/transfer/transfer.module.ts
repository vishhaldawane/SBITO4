import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NEFTTransferComponent } from './nefttransfer/nefttransfer.component';
import { IMPSTransferComponent } from './impstransfer/impstransfer.component';
import { RTGSTransferComponent } from './rtgstransfer/rtgstransfer.component';



@NgModule({
  declarations: [
    NEFTTransferComponent,
    IMPSTransferComponent,
    RTGSTransferComponent
  ],
  imports: [
    CommonModule
  ]
})
export class TransferModule { }
