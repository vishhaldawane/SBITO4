package com.example.demo.layer2;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="flights")
public class Flight {
	
	@Id
	@GeneratedValue
	@Column(name="FLIGHT_NO")
	private int flightNumber;
	
	@Column(name="AIRLINE", length=20)
	private String airline;
	
	@Column(name="SOURCE_CITY", length=20)
	private String sourceCity;
	
	@Column(name="TARGET_CITY", length=20)
	private String targetCity;
	
	@Column(name="DEP_TIME")
	private LocalDateTime flightDepartureTime;
	
	@Column(name="ARR_TIME")
	private LocalDateTime flightArrivalTime;
	
	public int getFlightNumber() {
		return flightNumber;
	}
	public void setFlightNumber(int flightNumber) {
		this.flightNumber = flightNumber;
	}
	public String getAirline() {
		return airline;
	}
	public void setAirline(String airline) {
		this.airline = airline;
	}
	public String getSourceCity() {
		return sourceCity;
	}
	public void setSourceCity(String sourceCity) {
		this.sourceCity = sourceCity;
	}
	public String getTargetCity() {
		return targetCity;
	}
	public void setTargetCity(String targetCity) {
		this.targetCity = targetCity;
	}
	public LocalDateTime getFlightDepartureTime() {
		return flightDepartureTime;
	}
	public void setFlightDepartureTime(LocalDateTime flightDepartureTime) {
		this.flightDepartureTime = flightDepartureTime;
	}
	public LocalDateTime getFlightArrivalTime() {
		return flightArrivalTime;
	}
	public void setFlightArrivalTime(LocalDateTime flightArrivalTime) {
		this.flightArrivalTime = flightArrivalTime;
	}
	
	
}
