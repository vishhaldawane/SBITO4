package com.example.demo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;

@SpringBootTest
class SpringBoot1ApplicationTests {

	@Autowired
	FlightRepository flightRepository;
	
	@Test
	void contextLoads() {
		Flight theFlight3 = new Flight();
		Flight theFlight4 = new Flight();
		Flight theFlight5 = new Flight();
		
		theFlight3.setAirline("British Airways");
		theFlight3.setSourceCity("Mumbai");
		theFlight3.setTargetCity("London");
		theFlight3.setFlightDepartureTime(LocalDateTime.of(2022, 8, 29, 22, 45));
		theFlight3.setFlightArrivalTime(LocalDateTime.of(2022, 8, 30, 06, 45));
		
		
		theFlight4.setAirline("Emirates");
		theFlight4.setSourceCity("Mumbai");
		theFlight4.setTargetCity("Dubai");
		theFlight4.setFlightDepartureTime(LocalDateTime.of(2022, 9, 25, 20, 30));
		theFlight4.setFlightArrivalTime(LocalDateTime.of(2022, 9, 27, 05, 30));
		
		theFlight5.setAirline("Ethiad");
		theFlight5.setSourceCity("Mumbai");
		theFlight5.setTargetCity("Abu Dhabi");
		theFlight5.setFlightDepartureTime(LocalDateTime.of(2022, 8, 28, 20, 30));
		theFlight5.setFlightArrivalTime(LocalDateTime.of(2022, 8, 28, 05, 30));
		
		
		
		flightRepository.save(theFlight3);
		flightRepository.save(theFlight4);
		flightRepository.save(theFlight5);
	}

	@Test
	void contextLoads2() {
		
		List<Flight> flightList = new ArrayList<Flight>();
		flightList  = (List<Flight>) flightRepository.findAll();
		for (Flight flight : flightList) {
			System.out.println("flight Number   : "+flight.getFlightNumber());
			System.out.println("flight Name     : "+flight.getAirline());
			System.out.println("flight Source   : "+flight.getSourceCity());
			System.out.println("flight Target   : "+flight.getTargetCity());
			System.out.println("flight Arrival  : "+flight.getFlightDepartureTime());
			System.out.println("flight Departure: "+flight.getFlightArrivalTime());
			System.out.println("------------------------");
		}
	}
}
