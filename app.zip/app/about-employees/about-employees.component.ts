import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-employees',
  templateUrl: './about-employees.component.html',
  styleUrls: ['./about-employees.component.css']
})
export class AboutEmployeesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
