import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddPayeeComponent } from './add-payee/add-payee.component';
import { ViewPayeeComponent } from './view-payee/view-payee.component';
import { DeletePayeeComponent } from './delete-payee/delete-payee.component';
import { ViewAllPayeesComponent } from './view-all-payees/view-all-payees.component';
import { ModifyPayeeLimitComponent } from './modify-payee-limit/modify-payee-limit.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    AddPayeeComponent,
    ViewPayeeComponent,
    DeletePayeeComponent,
    ViewAllPayeesComponent,
    ModifyPayeeLimitComponent
  ],
  exports: [
    AddPayeeComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class PayeeModule { }
