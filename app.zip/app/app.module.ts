import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { SimpleInterestCalculatorComponent } from './simple-interest-calculator/simple-interest-calculator.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CurrencyConverterComponent } from './currency-converter/currency-converter.component';


import { CubePipe } from './cube.pipe'; 
import { PayeeModule } from './payee/payee.module';
import { StatementModule } from './statement/statement.module';
import { UserDetailsComponent } from './user-details/user-details.component';
import { HttpClientModule } from '@angular/common/http';
import { PhotoDetailsComponent } from './photo-details/photo-details.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { PrivacyComponent } from './privacy/privacy.component';
import { TermsComponent } from './terms/terms.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AboutEmployeesComponent } from './about-employees/about-employees.component';
import { AboutCompanyComponent } from './about-company/about-company.component';
import { EmployeeComponent } from './employee/employee.component';
import { Employee1Component } from './employee1/employee1.component';
import { Employee2Component } from './employee2/employee2.component';
import { Employee3Component } from './employee3/employee3.component';
import { FlightComponent } from './flight/flight.component';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    SimpleInterestCalculatorComponent,
    CurrencyConverterComponent,
    CubePipe,
    UserDetailsComponent,
    PhotoDetailsComponent,
    HomeComponent,
    AboutComponent,
    PrivacyComponent,
    TermsComponent,
    PageNotFoundComponent,
    AboutEmployeesComponent,
    AboutCompanyComponent,
    EmployeeComponent,
    Employee1Component,
    Employee2Component,
    Employee3Component,
    FlightComponent
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    PayeeModule,
    StatementModule,
    HttpClientModule,
    ReactiveFormsModule
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
