import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  empNumber!:number;
  empName!:string;
  empEmail!:string;
  empBirthdate!:Date;

  constructor() { }

  ngOnInit(): void {
  }

  empnoErrorMsg!:string;
  validateFormData() {
    console.log('validateFormData invoked...');
      if(this.empNumber<1 || this.empNumber>1000) {
        this.empnoErrorMsg="Invalid Emp number";
      }
     else {
      this.empnoErrorMsg="OK";
      }
  }

  submitFormDataHere () {
    this.validateFormData();
    console.log('submitFormDataHere() invoked...');
    console.log('Emp Number : '+this.empNumber);
    console.log('Emp Name   : '+this.empName);
    console.log('Emp Email  : '+this.empEmail);
    console.log('Emp DOB    : '+this.empBirthdate);
  }

}
