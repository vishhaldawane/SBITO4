import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-impstransfer',
  templateUrl: './impstransfer.component.html',
  styleUrls: ['./impstransfer.component.css']
})
export class IMPSTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
