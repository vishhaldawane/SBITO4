import { Component, OnInit } from '@angular/core';
import { User } from '../User';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  userObj: User = new User();

  constructor() { 
    this.userObj.username='Jayant';
    this.userObj.password='Pearl';
    sessionStorage.setItem('anyKey',JSON.stringify(this.userObj));
  }

  ngOnInit(): void {
  }

}
