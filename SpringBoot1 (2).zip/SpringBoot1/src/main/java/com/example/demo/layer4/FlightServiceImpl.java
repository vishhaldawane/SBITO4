package com.example.demo.layer4;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.FlightNotFoundException;
import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepository;
	
	@Override
	public Flight findFlightByIdService(int flightId) throws FlightNotFoundException
	{
		System.out.println("4 : Service Layer");
		Optional<Flight> flight = flightRepository.findById(flightId);
		
		if(flight.isPresent()) {
			return flight.get();
		}
		else {
			throw new FlightNotFoundException("Flight With This ID "
					+ "doesnot exist!!!");
		}
		
	}

}
