package com.example.demo.layer4;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exceptions.FlightListEmptyException;
import com.example.demo.exceptions.FlightNotFoundException;
import com.example.demo.layer2.Flight;
import com.example.demo.layer3.FlightRepository;

@Service
public class FlightServiceImpl implements FlightService {

	@Autowired
	FlightRepository flightRepository;
	
	@Override
	public Flight findFlightByIdService(int flightId) throws FlightNotFoundException
	{
		System.out.println("4 : Service Layer");
		Optional<Flight> flight = flightRepository.findById(flightId);
		
		if(flight.isPresent()) {
			return flight.get();
		}
		else {
			throw new FlightNotFoundException("Flight With This ID "
					+ "doesnot exist!!!");
		}
		
	}

	public List<Flight> findAllFlightsService() throws FlightListEmptyException
	{
		System.out.println("4 : Service Layer");
		List<Flight> flightList = (List<Flight>) flightRepository.findAll();
		
		if(flightList.size() > 0 ) {
			return flightList;
		}
		else {
			throw new FlightListEmptyException("Flight list is empty...");
		}
		
	}
	
	public Flight	    saveService(Flight flightObj) 
	{
		Flight flightSaved =null;
		System.out.println("4 : Service Layer");
		Optional<Flight> flight = flightRepository.findById(flightObj.getFlightNumber());
		
		if(flight.isPresent()) {
			 flightSaved = flightRepository.save(flightObj);	
		}
		/*else {
			throw new FlightNotFoundException("Flight With This ID "
					+ "doesnot exist!!!");
		}*/
		return flightSaved;
	}
	
	public void         deleteByIdService(int flightId) throws FlightNotFoundException
	{
		System.out.println("4 : Service Layer");
		Optional<Flight> flight = flightRepository.findById(flightId);
		
		if(flight.isPresent()) {
			flightRepository.deleteById(flightId);
		}
		else {
			throw new FlightNotFoundException("Flight With This ID "
					+ "doesnot exist!!!");
		}
	}
}
