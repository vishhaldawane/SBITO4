package com.example.demo.exceptions;

public class FlightListEmptyException extends Exception {

	public FlightListEmptyException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}