package com.example.demo;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.Flight;

//REpresentational "State" Transfer
//plain html xml json 

//DispatcherServlet

// http://localhost:8080/enquiry/greet

@RestController
@RequestMapping("/enquiry")
public class FlightEnquiryController {

	//global
	List<Flight> flightList = new ArrayList<Flight>();
	
	public FlightEnquiryController() {
		System.out.println("FlightEnquiry() ctor.....");
		Flight theFlight1 = new Flight();
		Flight theFlight2 = new Flight();
		Flight theFlight3 = new Flight();
		
		theFlight1.setFlightNumber(101);
		theFlight1.setAirline("Air India");
		theFlight1.setSourceCity("Mumbai");
		theFlight1.setTargetCity("London");
		theFlight1.setFlightDepartureTime(LocalDateTime.of(2022, 06, 29, 22, 30));
		theFlight1.setFlightArrivalTime(LocalDateTime.of(2022, 06, 30, 06, 30));
		
		theFlight2.setFlightNumber(102);
		theFlight2.setAirline("Air America");
		theFlight2.setSourceCity("Mumbai");
		theFlight2.setTargetCity("Washington");
		theFlight2.setFlightDepartureTime(LocalDateTime.of(2022, 07, 25, 21, 30));
		theFlight2.setFlightArrivalTime(LocalDateTime.of(2022, 07, 27, 07, 30));
		
		
		theFlight3.setFlightNumber(103);
		theFlight3.setAirline("Air France");
		theFlight3.setSourceCity("Mumbai");
		theFlight3.setTargetCity("Paris");
		theFlight3.setFlightDepartureTime(LocalDateTime.of(2022, 8, 25, 20, 30));
		theFlight3.setFlightArrivalTime(LocalDateTime.of(2022, 8, 27, 05, 30));
		

		
		flightList.add(theFlight1);
		flightList.add(theFlight2);
		flightList.add(theFlight3);
	}
	@RequestMapping("/greet")
	public String greeting1() {
		System.out.println("greeting1() .....");
		return "<h1>Greeting from flight enquiry</h1>";
	}
	@RequestMapping("/welcome")
	public String greeting2() {
		System.out.println("greeting() .....");
		return "<h1>Welcome from flight enquiry</h1>";
	}
	@RequestMapping("/bye")
	public String greeting3() {
		System.out.println("greeting3() .....");
		return "<h1>Bye to flight enquiry</h1>";
	}
	//http://localhost:8080/enquiry/getFlight
	@GetMapping("/getFlightOne")
	public Flight getSingleFlightObject() {
		
		System.out.println("getSingleFlightObject() .....");
		
		Flight theFlight = new Flight();
		theFlight.setFlightNumber(101);
		theFlight.setAirline("Air India");
		theFlight.setSourceCity("Mumbai");
		theFlight.setTargetCity("London");
		theFlight.setFlightDepartureTime(
			LocalDateTime.of(2022, 06, 29, 22, 30));
		theFlight.setFlightArrivalTime(LocalDateTime.of(2022, 06, 30, 06, 30));
		return theFlight;
	}

	// http://localhost:8080/enquiry/getFlight/101
	@GetMapping("/getFlight/{fid}")
	public Flight getFlightObject(@PathVariable("fid") int flightNumber) {
		Flight tempFlight = null;
		System.out.println("getFlightObject() .....");
		for (Flight flight : flightList) {
			if(flight.getFlightNumber() == flightNumber) {
				tempFlight = flight;
				break;
			}
		}
		return tempFlight;
	}
	
	@PostMapping("/addFlight")
	public ResponseStatus addFlightObject(@RequestBody Flight flightObj) {
		System.out.println("addFlightObject() .....");
		flightList.add(flightObj);
		ResponseStatus resp = new ResponseStatus(); 
		resp.setMessage("Flight added successfully....");
		return resp;
	}
	
	@PutMapping("/modifyFlight")
	public ResponseStatus modifyFlightObject(@RequestBody Flight flightObj) {
		System.out.println("modifyFlightObject() .....");
		boolean found=false;
		for (int i=0;i<flightList.size();i++) {
			Flight tempFlight = flightList.get(i);
			if(tempFlight.getFlightNumber() == flightObj.getFlightNumber()) {
				flightList.remove(i); flightList.add(flightObj);
				found=true;	break;
			}
		}
		ResponseStatus resp = new ResponseStatus();
		if(found==true) {resp.setMessage("Flight updated successfully....");
		}
		else {resp.setMessage("Flight NOT Found...."+flightObj.getFlightNumber());
		}
		return resp;
	}
	
	@DeleteMapping("/deleteFlight/{fno}")
	public ResponseStatus deleteFlightObject(@PathVariable("fno") int flightNumber) {
		System.out.println("deleteFlightObject() .....");
		boolean found=false;
		for (int i=0;i<flightList.size();i++) {
			Flight tempFlight = flightList.get(i);
			if(tempFlight.getFlightNumber() == flightNumber) {
				flightList.remove(i); 
				found=true;	break;
			}
		}
		ResponseStatus resp = new ResponseStatus();
		if(found==true) {resp.setMessage("Flight deleted successfully....");
		}
		else {resp.setMessage("Flight NOT Found...."+flightNumber);
		}
		return resp;
	}
	
	@GetMapping("/getFlights")
	public List<Flight> getAllFlightObjects() {
		System.out.println("getAllFlightObjects() .....");
		return flightList;
	}
}
