package onetoone;

import java.sql.Date;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import bank.dao.BaseDAO;
import bank.dao.BaseDAOImpl;

public class OneToOneTesting {

	BaseDAO base = new BaseDAOImpl();
	
	@Test
	public void addEmployeeWithoutPassportTest() {
		
		Employee empObj1 = new Employee();
		empObj1.setEmployeeName("Jack");
		empObj1.setBasicSalary(5000);
		
		Employee empObj2 = new Employee();
		empObj2.setEmployeeName("Jane");
		empObj2.setBasicSalary(6000);
		
		Employee empObj3 = new Employee();
		empObj3.setEmployeeName("Julie");
		empObj3.setBasicSalary(7000);
		
		
		base.persist(empObj1);
		base.persist(empObj2);
		base.persist(empObj3);
		
		
	}
	
	@Test
	public void addPassportWithoutEmployeesTest() {
		
		Passport passport1 = new Passport();
		passport1.setIssuedBy("Govt Of Ind");
		
		String issuedDate1 = "2022-12-25";
		java.sql.Date issuedDateInSQL1 = Date.valueOf(issuedDate1);
		passport1.setPassportIssuedDate(issuedDateInSQL1);
		
		String expiryDate1 = "2032-12-25";
		java.sql.Date expiryDateInSQL1 = Date.valueOf(expiryDate1);
		passport1.setPassportExpiryDate(expiryDateInSQL1);
		
		
		
		Passport passport2 = new Passport();
		passport2.setIssuedBy("Govt Of Ind");
		
		String issuedDate2 = "2021-12-20";
		java.sql.Date issuedDateInSQL2 = Date.valueOf(issuedDate2);
		passport2.setPassportIssuedDate(issuedDateInSQL2);
		
		String expiryDate2 = "2031-12-25";
		java.sql.Date expiryDateInSQL2 = Date.valueOf(expiryDate2);
		passport2.setPassportExpiryDate(expiryDateInSQL2);
		
		
		Passport passport3 = new Passport();
		passport3.setIssuedBy("Govt Of Ind");
		
		String issuedDate3 = "2019-12-18";
		java.sql.Date issuedDateInSQL3 = Date.valueOf(issuedDate3);
		passport3.setPassportIssuedDate(issuedDateInSQL3);
		
		String expiryDate3 = "2029-12-18";
		java.sql.Date expiryDateInSQL3 = Date.valueOf(expiryDate3);
		passport3.setPassportExpiryDate(expiryDateInSQL3);
		
		
		base.persist(passport1);
		base.persist(passport2);
		base.persist(passport3);
		
	}
	
	@Test
	public void assignExistingPassportToExistingEmployee() {
		
		
		Employee theEmp = base.find(Employee.class,24);
		Passport thePass = base.find(Passport.class, 27);
		
		Assertions.assertTrue(theEmp!=null);
		Assertions.assertTrue(thePass!=null);
		
		theEmp.setPassport(thePass); //attached object is modified
		thePass.setEmployee(theEmp); //attached object is modified
		
		base.merge(theEmp); //update query
		base.merge(thePass); //update query
		
	}
	
	@Test
	public void addNewEmployeeWithNewPassport() {
		
		Employee newEmp = new Employee();
		newEmp.setEmployeeName("Robert");
		newEmp.setBasicSalary(420);
		
		Passport newPass = new Passport();
		newPass.setIssuedBy("Govt Of Ind");
		
		String issuedDate3 = "2023-12-18";
		java.sql.Date issuedDateInSQL3 = Date.valueOf(issuedDate3);
		newPass.setPassportIssuedDate(issuedDateInSQL3);
		
		String expiryDate3 = "2033-12-18";
		java.sql.Date expiryDateInSQL3 = Date.valueOf(expiryDate3);
		newPass.setPassportExpiryDate(expiryDateInSQL3);
		
		
		newEmp.setPassport(newPass);
		newPass.setEmployee(newEmp);
		
		base.persist(newEmp);
		base.persist(newPass);
		
	}
	
}







