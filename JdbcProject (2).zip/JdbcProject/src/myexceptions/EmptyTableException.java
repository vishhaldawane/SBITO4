package myexceptions;
public class EmptyTableException extends RuntimeException {
	public EmptyTableException(String msg) {
		super(msg);
	}
}
