import java.sql.Date;
import java.util.List;

import dao.Employee;
import dao.EmployeeDAOImpl;
import myexceptions.EmployeeNotFoundException;

public class TestDAO3 {
	public static void main(String[] args) {
		EmployeeDAOImpl empDAO = new EmployeeDAOImpl();
		
		Employee empObj = new Employee();
		empObj.setEmployeeNumber(1999);
		empObj.setEmployeeName("Robert");
		empObj.setJob("Clerk");
		empObj.setEmployeeManagerCode(7839);
		
		String str ="2022-12-25";
		java.sql.Date doj = Date.valueOf(str);
		
		empObj.setEmployeeHiringDate(doj);
		empObj.setBasicSalary(4400);
		empObj.setCommission(555);
		empObj.setDepartmentNumber(10);
		
		empDAO.createEmployee(empObj);
		
		empDAO.closeDBResources();
	}
}
