package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import myexceptions.EmployeeAlreadyExistsException;
import myexceptions.EmployeeNotFoundException;
import myexceptions.EmptyTableException;

public class EmployeeDAOImpl implements EmployeeDAO {

	Connection conn; //global connection
	public void closeDBResources() {
		try {
			conn.close();
			System.out.println("DB connection is closed....");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public EmployeeDAOImpl() {
		try {
			System.out.println("Trying to load the driver...");
			DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
			System.out.println("Loaded the driver.....");
			
			System.out.println("Trying to connect to the DB...");
			conn = DriverManager.getConnection("jdbc:oracle:thin:"
					+ "@localhost:1521:xe",
					"system", "sysgitc");
			System.out.println("connected to the db...."+conn);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@Override
	public void createEmployee(Employee empObj) throws EmployeeAlreadyExistsException {
		int rowsInserted;
		try {
			System.out.println("Trying to create PreparedStatement...");
			PreparedStatement pst = conn.prepareStatement("insert into emp values (?,?,?,?,?,?,?,?)");
			System.out.println("PreparedStatement created : "+pst);
			
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select * from emp where empno="+empObj.getEmployeeNumber());
			if(rs.next()) {
				EmployeeAlreadyExistsException ex = new EmployeeAlreadyExistsException("Employee number already present : "+empObj.getEmployeeNumber());
				throw ex;
			}
			
			pst.setInt(1, empObj.getEmployeeNumber());
			pst.setString(2, empObj.getEmployeeName());
			pst.setString(3, empObj.getJob());
			pst.setInt(4, empObj.getEmployeeManagerCode());
			pst.setDate(5, empObj.getEmployeeHiringDate());
			pst.setDouble(6, empObj.getBasicSalary());
			pst.setDouble(7, empObj.getCommission());
			pst.setInt(8, empObj.getDepartmentNumber());
			
			rowsInserted = pst.executeUpdate();
			//conn.commit();
			System.out.println("Statement executed : rows created : "+rowsInserted);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public Employee readEmployee(int empNumber) throws EmployeeNotFoundException {
		
		Employee empObj = null;
		
		try {
			System.out.println("Trying to create statement...");
			Statement statement = conn.createStatement();
			System.out.println("Statement created : "+statement);
			
			System.out.println("Trying to execute statement...");
			ResultSet resultSet = statement.executeQuery("SELECT * FROM emp where empno="+empNumber);
			
			System.out.println("Statement executed : got the result : "+resultSet);
			
			if(resultSet.next()) {
				empObj = new Employee(); //create a blank employee object
				
				//and fill it up if record is there
				empObj.setEmployeeNumber(resultSet.getInt(1));
				empObj.setEmployeeName(resultSet.getString(2));
				empObj.setJob(resultSet.getString(3));
				empObj.setEmployeeManagerCode(resultSet.getInt(4));
				empObj.setEmployeeHiringDate(resultSet.getDate(5));
				empObj.setBasicSalary(resultSet.getDouble(6));
				empObj.setCommission(resultSet.getDouble(7));
				empObj.setDepartmentNumber(resultSet.getInt(8));
			}
			else {
				throw new EmployeeNotFoundException("Employee Number does not exits : "+empNumber);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empObj;
	}

	@Override
	public List<Employee> readAllEmployees() throws EmptyTableException {
		
		List<Employee> empList = new <Employee>ArrayList();
		
		Employee empObj = null;
		
		try {
			System.out.println("Trying to create statement...");
			Statement statement = conn.createStatement();
			System.out.println("Statement created : "+statement);
			
			System.out.println("Trying to execute statement...");
			ResultSet resultSet = statement.executeQuery("SELECT * FROM emp ");
			
			System.out.println("Statement executed : got the result : "+resultSet);
			
			while(resultSet.next()) {
				empObj = new Employee(); //create a blank employee object
				
				//and fill it up if record is there
				empObj.setEmployeeNumber(resultSet.getInt(1));
				empObj.setEmployeeName(resultSet.getString(2));
				empObj.setJob(resultSet.getString(3));
				empObj.setEmployeeManagerCode(resultSet.getInt(4));
				empObj.setEmployeeHiringDate(resultSet.getDate(5));
				empObj.setBasicSalary(resultSet.getDouble(6));
				empObj.setCommission(resultSet.getDouble(7));
				empObj.setDepartmentNumber(resultSet.getInt(8));
				
				empList.add(empObj); // list is being populated with new object 
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return empList;
	}
	
	@Override
	public void updateEmployee(Employee empObj) throws EmployeeNotFoundException {

		try {
			System.out.println("Trying to create PreparedStatement...");
			PreparedStatement pst = conn.prepareStatement("UPDATE emp set ename=?,job=?,mgr=?,hiredate=?,sal=?,comm=?,deptno=? where empno=?");
			System.out.println("PreparedStatement created : "+pst);
			
			System.out.println("Trying to execute statement...");
			
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select * from emp where empno="+empObj.getEmployeeNumber());
			if(rs.next()) {
				pst.setString(1, empObj.getEmployeeName());
				pst.setString(2, empObj.getJob());
				pst.setInt(3, empObj.getEmployeeManagerCode());
				pst.setDate(4, empObj.getEmployeeHiringDate());
				pst.setDouble(5, empObj.getBasicSalary());
				pst.setDouble(6, empObj.getCommission());
				pst.setInt(7, empObj.getDepartmentNumber());
				
				pst.setInt(8, empObj.getEmployeeNumber()); //for this to update
				
				int rowsUpdated = pst.executeUpdate();
				System.out.println("Statement executed : rows updated: "+rowsUpdated);
			}
			else {
				EmployeeNotFoundException ex = new EmployeeNotFoundException("This employee number does not exists : "+empObj.getEmployeeNumber());
				throw ex;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void deleteEmployee(int empNumber) throws EmployeeNotFoundException {
		try {
			System.out.println("Trying to create PreparedStatement...");
			PreparedStatement pst = conn.prepareStatement("delete from emp where empno=?");
			System.out.println("PreparedStatement created : "+pst);
			
			System.out.println("Trying to execute statement...");
			
			
			Statement statement = conn.createStatement();
			ResultSet rs = statement.executeQuery("select * from emp where empno="+empNumber);
			
			if(rs.next()) {
				pst.setInt(1, empNumber );
				int rowsDeleted = pst.executeUpdate();
				System.out.println("Statement executed : rows deleted : "+rowsDeleted);
			}
			else {
				EmployeeNotFoundException ex = new EmployeeNotFoundException("Employee not found : "+empNumber);
				throw ex;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
