package onetoone;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="passport12")
public class Passport {

	@Id 	@GeneratedValue 	@Column(name="passport_number")
	private int passportNumber;
	@Column(name="issued_by", length=20)
	private String issuedBy;
	@Column(name="passport_issued")
	private Date passportIssuedDate;
	@Column(name="passport_expiry")
	private Date passportExpiryDate;
	
	@OneToOne
	//@JoinColumn(name="eno")
	private Employee employee;

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

	public int getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(int passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getIssuedBy() {
		return issuedBy;
	}

	public void setIssuedBy(String issuedBy) {
		this.issuedBy = issuedBy;
	}

	public Date getPassportIssuedDate() {
		return passportIssuedDate;
	}

	public void setPassportIssuedDate(Date passportIssuedDate) {
		this.passportIssuedDate = passportIssuedDate;
	}

	public Date getPassportExpiryDate() {
		return passportExpiryDate;
	}

	public void setPassportExpiryDate(Date passportExpiryDate) {
		this.passportExpiryDate = passportExpiryDate;
	}

	public Passport(int passportNumber, String issuedBy, Date passportIssuedDate, Date passportExpiryDate) {
		super();
		this.passportNumber = passportNumber;
		this.issuedBy = issuedBy;
		this.passportIssuedDate = passportIssuedDate;
		this.passportExpiryDate = passportExpiryDate;
	}

	public Passport() {
		//super(); //hidden line of each ctor
		// TODO Auto-generated constructor stub
	}
	
	
}
