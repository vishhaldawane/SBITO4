package bank.dao;

import java.util.List;

import bank.SavingsAccount;

public interface SavingsAccountDAO {
	void createSavingsAccount(SavingsAccount sa);
	void updateSavingsAccount(SavingsAccount sa);
	void deleteSavingsAccount(int savAccNo);
	SavingsAccount readSavingsAccount(int savAccNo);
	List<SavingsAccount> readAllSavingsAccounts();
}
