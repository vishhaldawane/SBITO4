package bank.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import bank.SavingsAccount;

public class SavingsAccountDAOImpl implements SavingsAccountDAO {

	EntityManager entityManager;
	
	public SavingsAccountDAOImpl() {
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the Entity Manager Factory : "+entityManagerFactory);
		
		entityManager = 
				entityManagerFactory.createEntityManager();
		System.out.println("Entity Manager : "+entityManager );
		
	}
	
	@Override
	public void createSavingsAccount(SavingsAccount sa) {
		
		entityManager.getTransaction().begin();
			entityManager.persist(sa);
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void updateSavingsAccount(SavingsAccount sa) {
		entityManager.getTransaction().begin();
			entityManager.merge(sa);
		entityManager.getTransaction().commit();
	}

	@Override
	public void deleteSavingsAccount(int savAccNo) {
		entityManager.getTransaction().begin();
			SavingsAccount savAcc = entityManager.find(SavingsAccount.class, savAccNo);
			entityManager.remove(savAcc);
		entityManager.getTransaction().commit();
	}

	@Override
	public SavingsAccount readSavingsAccount(int savAccNo) {
		return entityManager.find(SavingsAccount.class, savAccNo);
	}

	@Override
	public List<SavingsAccount> readAllSavingsAccounts() {
		return entityManager.createQuery("from SavingsAccount").getResultList();
	}

}
