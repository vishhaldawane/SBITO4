package bank.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public interface BaseDAO {
	public 			 void          persist(Object obj);
	public 			 void          merge(Object obj);
	public 			 void          remove(Object obj);
	public <Unknown> Unknown       find(Class<Unknown> className, Serializable primaryKey );
	public <Unknown> List<Unknown> findAll(String entityName);
}

