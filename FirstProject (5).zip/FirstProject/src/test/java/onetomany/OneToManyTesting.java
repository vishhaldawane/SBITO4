package onetomany;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import bank.dao.BaseDAO;
import bank.dao.BaseDAOImpl;
import onetoone.Employee;

public class OneToManyTesting {
	
	BaseDAO base = new BaseDAOImpl();
	
	@Test
	public void addNewDepartmentWithNewEmployees() {
		
		Department dept = new Department(30, "Sales", "New Delhi");
		
		Employee emp1 = new Employee("Suresh",5000,dept);
		Employee emp2 = new Employee("Naresh",6000,dept);
		Employee emp3 = new Employee("Rajesh",7000,dept);
		
		List<Employee> newEmpList = new ArrayList<Employee>();
		newEmpList.add(emp1);
		newEmpList.add(emp2);
		newEmpList.add(emp3);
		
		dept.setEmployees(newEmpList);
		
		base.persist(dept);
		
	}
}
