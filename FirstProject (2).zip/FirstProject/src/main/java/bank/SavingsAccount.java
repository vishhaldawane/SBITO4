package bank;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity //a business unit identified by its primary key
@Table(name="sav_acc")
public class SavingsAccount { 

	@Id
	@Column(name="AC_NO")
	private int accno; 
	
	@Column(name="AC_HOLDER",length=20)
	private String accHolder; 
	
	@Column(name="AC_BAL")
	private double balance; 
	
	
	
	
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(String accHolder) {
		this.accHolder = accHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "SavingsAccount [accno=" + accno + ", accHolder=" + accHolder + ", balance=" + balance + "]";
	}
	
	public SavingsAccount() {
		System.out.println("SavingsAccount : Explicit no-arg ctor....");
	}
	
	
	
}
