import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import bank.SavingsAccount;

//TDD - test driven development

public class SavingsAccountTesting {

	EntityManagerFactory entityManagerFactory = 
			Persistence.createEntityManagerFactory("MyJPA");
	//System.out.println("Got the Entity Manager Factory : "+entityManagerFactory);
	
	EntityManager entityManager = 
			entityManagerFactory.createEntityManager();
	//System.out.println("Entity Manager : "+entityManager );
	
	@Test
	public void creationOfSavingsAccountTest()
	{
		System.out.println("Begin testing....");
		SavingsAccount savObj = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj.setAccno(122);
		savObj.setAccHolder("Jane");
		savObj.setBalance(70000);
		System.out.println("Object is filled up....");
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
				entityManager.persist(savObj); //INSERT QUERY FIRED HERE
				System.out.println("Savings Account Object persited...");
		trans.commit(); //end the transaction
		
		entityManager.close();
		System.out.println("Entity Manager closed.....");
		
		System.out.println("End testing....");
	}
	
	@Test 
	public void findSavingsAccountTest() {
		Assertions.assertTrue(entityManagerFactory!=null);
		Assertions.assertTrue(entityManager!=null);
		SavingsAccount sa = entityManager.find(SavingsAccount.class, 120);
		Assertions.assertTrue(sa!=null);
		System.out.println("Object found...");
		System.out.println("ACNO   : "+sa.getAccno());
		System.out.println("ACNAME : "+sa.getAccHolder());
		System.out.println("ACBAL  : "+sa.getBalance());
	}
	
	@Test 
	public void modifySavingsAccountTest() {
		Assertions.assertTrue(entityManagerFactory!=null);
		Assertions.assertTrue(entityManager!=null);
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
		
			SavingsAccount sa = entityManager.find(SavingsAccount.class, 120);
			//	attached with the ORM session
			Assertions.assertTrue(sa!=null);
			System.out.println("Object found...");
			System.out.println("current ACNO   : "+sa.getAccno());
			System.out.println("current ACNAME : "+sa.getAccHolder());
			System.out.println("current ACBAL  : "+sa.getBalance());
		
			System.out.println("Setting new details on the object...");
			
			sa.setAccHolder("Juliet");
			sa.setBalance(55000);
		
			entityManager.merge(sa); // update query fired..
			
		trans.commit();
	}
}
