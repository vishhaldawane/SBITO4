package bank;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity //a business unit identified by its primary key
public class SavingsAccount { 

	@Id
	private int accno; 
	private String accHolder; 
	private double balance; 
	
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(String accHolder) {
		this.accHolder = accHolder;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "SavingsAccount [accno=" + accno + ", accHolder=" + accHolder + ", balance=" + balance + "]";
	}
	
	public SavingsAccount() {
		System.out.println("SavingsAccount : Explicit no-arg ctor....");
	}
	
	
	
}
