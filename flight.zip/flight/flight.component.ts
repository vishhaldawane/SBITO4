import { Component, OnInit } from '@angular/core';
import { FlightService } from '../flight.service';
import { Flight } from './Flight';

@Component({
  selector: 'app-flight',
  templateUrl: './flight.component.html',
  styleUrls: ['./flight.component.css']
})
export class FlightComponent implements OnInit {

  flightObject: Flight = new Flight();

  constructor(private flightService:FlightService) { }

  ngOnInit(): void {
  }
  findFlight() {
    this.flightService.loadFlightObjectFromSpring(this.flightObject.flightNumber).subscribe
    (
      {
        next: (data: any) =>  {
          this.flightObject = data;
          console.log(data);
        },
        complete: () => {},
        error: () => { console.log(console.error()); }
      }
   );
  }
}
