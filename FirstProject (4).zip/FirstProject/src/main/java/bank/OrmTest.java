package bank;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class OrmTest {
	public static void main(String[] args) {
		//following line would read META-INF/persistence.xml 
		//and its settings
		EntityManagerFactory entityManagerFactory = 
				Persistence.createEntityManagerFactory("MyJPA");
		System.out.println("Got the Entity Manager Factory : "+entityManagerFactory);
		
		EntityManager entityManager = 
				entityManagerFactory.createEntityManager();
		System.out.println("Entity Manager : "+entityManager );
		
		SavingsAccount savObj = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj.setAccno(120);
		savObj.setAccHolder("Julie");
		savObj.setBalance(50000);
		System.out.println("Object is filled up....");
		
		EntityTransaction trans = entityManager.getTransaction();
		System.out.println("Got the Entity Transaction : "+trans);
		
		trans.begin(); //begin the transaction		
				entityManager.persist(savObj); //INSERT QUERY FIRED HERE
				System.out.println("Savings Account Object persited...");
		trans.commit(); //end the transaction
		
		entityManager.close();
		System.out.println("Entity Manager closed.....");
		
		
	}
}
//FlowerShop fs= new FlowerShop();
//FlowerFactory ff = Garden.createFlowerFactory("design");
//System.out.println("ff "+ff);
interface FlowerFactory
{
	
}
class FlowerShop implements FlowerFactory
{
	
} 
class DesignerFlowerShop implements FlowerFactory
{
	
}
class FragranceBasedFlowerShop implements FlowerFactory
{
	
} 

abstract class Garden
{
	static FlowerFactory createFlowerFactory(String hint)
	{
		FlowerFactory ff = null;
		
		if(hint.equalsIgnoreCase("basic"))
			ff = new FlowerShop();
		else if (hint.equalsIgnoreCase("design"))
			ff = new DesignerFlowerShop();
		else if(hint.equalsIgnoreCase("fragrance"))
			ff = new FragranceBasedFlowerShop();
		
		return ff;
	}
}





