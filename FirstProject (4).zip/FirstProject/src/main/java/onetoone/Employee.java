package onetoone;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="employee12")
public class Employee {

	@Id 	@GeneratedValue @Column(name="empno")
	private int employeeNumber;
	
	@Column(name="emp_name", length=20)
	private String employeeName;
	
	@Column(name="emp_basic_sal")
	private double basicSalary;
	
	//@OneToOne(mappedBy="employee")
	
	@OneToOne(cascade = CascadeType.ALL)
	private Passport passport; //ref

	public Passport getPassport() {
		return passport;
	}

	public void setPassport(Passport passport) {
		this.passport = passport;
	}

	public int getEmployeeNumber() {
		return employeeNumber;
	}

	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public double getBasicSalary() {
		return basicSalary;
	}

	public void setBasicSalary(double basicSalary) {
		this.basicSalary = basicSalary;
	}

	public Employee(int employeeNumber, String employeeName, double basicSalary) {
		super();
		this.employeeNumber = employeeNumber;
		this.employeeName = employeeName;
		this.basicSalary = basicSalary;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}


