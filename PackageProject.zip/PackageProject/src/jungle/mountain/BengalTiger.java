package jungle.mountain;

import jungle.cave.Tiger;

public class BengalTiger extends Tiger {
	void bengalTigerPrintingIt() {
		System.out.println("defaultAge  : "+defaultAge);
		System.out.println("privateAge  : "+privateAge);
		System.out.println("protectedAge: "+protectedAge);
		System.out.println("publicAge   : "+publicAge);
	}
	void printAgain() {
		Tiger t = new Tiger();
		System.out.println("defaultAge  : "+t.defaultAge);
		System.out.println("privateAge  : "+t.privateAge);
		System.out.println("protectedAge: "+t.protectedAge);
		System.out.println("publicAge   : "+t.publicAge);
	}
}
