package jungle.tree;
//THOUGHTS + FEELINGS = TIME = ACTION + RESULT
//FREQUENCY					FREQUENCY

import jungle.cave.Tiger;

public class Parrot {
	
	void parrotIsPrintingIt() {
		Tiger t = new Tiger();
		System.out.println("defaultAge  : "+t.defaultAge);
		System.out.println("privateAge  : "+t.privateAge);
		System.out.println("protectedAge: "+t.protectedAge);
		System.out.println("publicAge   : "+t.publicAge);
	}
}
