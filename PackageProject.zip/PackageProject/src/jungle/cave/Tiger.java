package jungle.cave;
//public class always contains a default public ctor
public class Tiger {
	
	          int  	defaultAge=1; // nonchild-child [ must be within the same package ]
	private   int 	privateAge=2; // only within the class
	protected int 	protectedAge=3;// child
	public    int 	publicAge=4;
	
	public Tiger() {
		System.out.println("Tiger ctor...");
	}
	public void roar() {
		System.out.println("Tiger is roaring.....");
	}
	void tigerPrintingIt() {
		System.out.println("defaultAge  : "+defaultAge);
		System.out.println("privateAge  : "+privateAge);
		System.out.println("protectedAge: "+protectedAge);
		System.out.println("publicAge   : "+publicAge);
	}
}
class Monkey //Non-child [ of Tiger ] but in the same package
{
	void jump() {
		Tiger t  = new Tiger();
		System.out.println("defaultAge  : "+t.defaultAge);
		System.out.println("privateAge  : "+t.privateAge);
		System.out.println("protectedAge: "+t.protectedAge);
		System.out.println("publicAge   : "+t.publicAge);
	}
}

