package jungle.cave;

public class WhiteTiger extends Tiger {

	@Override
	public void roar() {
		System.out.println("White Tiger is roaring.....");
	}

	void whiteTigerPrintingIt() {
		System.out.println("defaultAge  : "+defaultAge);
		System.out.println("privateAge  : "+privateAge);
		System.out.println("protectedAge: "+protectedAge);
		System.out.println("publicAge   : "+publicAge);
	}
	void printAgain() {
		Tiger t = new Tiger();
		System.out.println("defaultAge  : "+t.defaultAge);
		System.out.println("privateAge  : "+t.privateAge);
		System.out.println("protectedAge: "+t.protectedAge);
		System.out.println("publicAge   : "+t.publicAge);
	}
}
