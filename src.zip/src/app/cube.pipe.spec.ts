import { CubePipe } from './cube.pipe';

describe('CubePipe', () => {
  it('create an instance', () => {
    const pipe = new CubePipe();
    expect(pipe).toBeTruthy();
  });
});
