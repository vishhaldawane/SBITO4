import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModifyPayeeLimitComponent } from './modify-payee-limit.component';

describe('ModifyPayeeLimitComponent', () => {
  let component: ModifyPayeeLimitComponent;
  let fixture: ComponentFixture<ModifyPayeeLimitComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModifyPayeeLimitComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModifyPayeeLimitComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
