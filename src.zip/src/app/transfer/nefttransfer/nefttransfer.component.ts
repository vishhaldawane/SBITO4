import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nefttransfer',
  templateUrl: './nefttransfer.component.html',
  styleUrls: ['./nefttransfer.component.css']
})
export class NEFTTransferComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
