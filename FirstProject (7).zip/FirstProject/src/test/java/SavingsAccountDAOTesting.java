import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import bank.SavingsAccount;
import bank.dao.SavingsAccountDAOImpl;

//TDD - test driven development

public class SavingsAccountDAOTesting {

	SavingsAccountDAOImpl savDAO = new SavingsAccountDAOImpl();
	
	@Test
	public void creationOfSavingsAccountTest()
	{
		System.out.println("Begin testing....");
		
		SavingsAccount savObj1 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj1.setAccno(111);
		savObj1.setAccHolder("Suresh");
		savObj1.setBalance(70000);
		
		SavingsAccount savObj2 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj2.setAccno(107);
		savObj2.setAccHolder("Naresh");
		savObj2.setBalance(80000);
		
		SavingsAccount savObj3 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj3.setAccno(108);
		savObj3.setAccHolder("Haresh");
		savObj3.setBalance(90000);
		
		SavingsAccount savObj4 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj4.setAccno(109);
		savObj4.setAccHolder("Jayesh");
		savObj4.setBalance(77000);
		
		SavingsAccount savObj5 = new SavingsAccount();
		System.out.println("Empty object is created....");
		savObj5.setAccno(110);
		savObj5.setAccHolder("Paresh");
		savObj5.setBalance(66600);
		
		savDAO.createSavingsAccount(savObj1);
		savDAO.createSavingsAccount(savObj2);
		savDAO.createSavingsAccount(savObj3);
		savDAO.createSavingsAccount(savObj4);
		savDAO.createSavingsAccount(savObj5);
		
		
		System.out.println("End testing....");
	}
	
	
	@Test 
	public void findSavingsAccountTest() {
		SavingsAccount sa = savDAO.readSavingsAccount(106);
		
		System.out.println("Object found...");
		System.out.println("ACNO   : "+sa.getAccno());
		System.out.println("ACNAME : "+sa.getAccHolder());
		System.out.println("ACBAL  : "+sa.getBalance());
	}
	
	@Test 
	public void findAllSavingsAccountsTest() {
		
		List<SavingsAccount> savObjList = savDAO.readAllSavingsAccounts();
		
		Assertions.assertTrue(savObjList.size()>0);
		for (SavingsAccount sa : savObjList) {
			System.out.println("ACNO   : "+sa.getAccno());
			System.out.println("ACNAME : "+sa.getAccHolder());
			System.out.println("ACBAL  : "+sa.getBalance());
			System.out.println("--------------------");
		}
	}
	
	@Test 
	public void modifySavingsAccountTest() {
		
			SavingsAccount sa = savDAO.readSavingsAccount(106);
			//	attached with the ORM session
			Assertions.assertTrue(sa!=null);
			System.out.println("Object found...");
			System.out.println("current ACNO   : "+sa.getAccno());
			System.out.println("current ACNAME : "+sa.getAccHolder());
			System.out.println("current ACBAL  : "+sa.getBalance());
		
			System.out.println("Setting new details on the object...");
			
			sa.setAccHolder("JAYANT");
			sa.setBalance(77777);
		
			savDAO.updateSavingsAccount(sa);
		
	}
	
	@Test 
	public void deleteSavingsAccountTest() {
		
			savDAO.deleteSavingsAccount(102);
	}
}
